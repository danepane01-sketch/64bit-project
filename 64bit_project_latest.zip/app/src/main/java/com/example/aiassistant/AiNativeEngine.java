package com.example.aiassistant;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.util.Log;

import org.tensorflow.lite.Interpreter;
import org.tensorflow.lite.nnapi.NnApiDelegate;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;

public class AiNativeEngine {
    private static final String TAG = "AiNativeEngine";
    private Interpreter tflite;
    private NnApiDelegate nnapiDelegate;

    public AiNativeEngine(Context ctx, String modelAssetPath, boolean useNNAPI) throws IOException {
        MappedByteBuffer model = loadModelFileFromAssets(ctx, modelAssetPath);
        Interpreter.Options options = new Interpreter.Options();
        if (useNNAPI) {
            try {
                nnapiDelegate = new NnApiDelegate();
                options.addDelegate(nnapiDelegate);
            } catch (Exception e) {
                Log.w(TAG, "NNAPI delegate not available, falling back to CPU/GPU", e);
            }
        }
        tflite = new Interpreter(model, options);
    }

    private MappedByteBuffer loadModelFileFromAssets(Context context, String assetPath) throws IOException {
        AssetFileDescriptor fileDescriptor = context.getAssets().openFd(assetPath);
        FileInputStream inputStream = new FileInputStream(fileDescriptor.getFileDescriptor());
        FileChannel fileChannel = inputStream.getChannel();
        long startOffset = fileDescriptor.getStartOffset();
        long declaredLength = fileDescriptor.getDeclaredLength();
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength);
    }

    // Example inference runner: input float[] => output float[]
    public float[] runInference(float[] input, int outputSize) {
        if (tflite == null) {
            Log.e(TAG, "Interpreter is null");
            return new float[0];
        }
        float[][] output = new float[1][outputSize];
        try {
            tflite.run(input, output);
        } catch (Exception e) {
            Log.e(TAG, "Inference failed", e);
        }
        return output[0];
    }

    public void close() {
        if (tflite != null) {
            tflite.close();
            tflite = null;
        }
        if (nnapiDelegate != null) {
            try { nnapiDelegate.close(); } catch (Exception e) {}
            nnapiDelegate = null;
        }
    }
}
