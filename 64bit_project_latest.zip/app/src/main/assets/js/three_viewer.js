
// three_viewer.js - lightweight WebGL demo (rotating cube)
// Simple, dependency-free WebGL renderer to preview a 3D model placeholder.
// Provides controls: play/pause, rotate speed, scale
(function(){
  const canvas = document.createElement('canvas');
  canvas.id = 'threeCanvas';
  canvas.style.width = '100%';
  canvas.style.height = '400px';
  canvas.style.display = 'block';
  canvas.style.background = '#222';
  const container = document.getElementById('threejs-viewer-container') || document.body;
  container.appendChild(canvas);

  let gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
  if(!gl){ 
    const p = document.createElement('p');
    p.textContent = 'WebGL tidak tersedia di browser ini.';
    container.appendChild(p);
    return;
  }

  function resize(){
    const w = canvas.clientWidth; const h = canvas.clientHeight;
    if(canvas.width !== w || canvas.height !== h){
      canvas.width = w; canvas.height = h;
      gl.viewport(0,0,gl.drawingBufferWidth, gl.drawingBufferHeight);
    }
  }
  window.addEventListener('resize', resize);

  // shader helpers
  function compileShader(src, type){
    const s = gl.createShader(type);
    gl.shaderSource(s, src);
    gl.compileShader(s);
    if(!gl.getShaderParameter(s, gl.COMPILE_STATUS)) {
      console.error('Shader compile error', gl.getShaderInfoLog(s));
    }
    return s;
  }

  const vs = `
    attribute vec3 position;
    attribute vec3 color;
    uniform mat4 uMVP;
    varying vec3 vColor;
    void main(){ vColor = color; gl_Position = uMVP * vec4(position, 1.0); }
  `;
  const fs = `
    precision mediump float;
    varying vec3 vColor;
    void main(){ gl_FragColor = vec4(vColor, 1.0); }
  `;
  const prog = gl.createProgram();
  gl.attachShader(prog, compileShader(vs, gl.VERTEX_SHADER));
  gl.attachShader(prog, compileShader(fs, gl.FRAGMENT_SHADER));
  gl.linkProgram(prog);
  gl.useProgram(prog);

  // cube data
  const positions = new Float32Array([
    -1,-1,-1,  1,-1,-1,  1,1,-1,  -1,1,-1,   // back face
    -1,-1,1,   1,-1,1,   1,1,1,   -1,1,1     // front face
  ]);
  const indices = new Uint16Array([
    0,1,2,  0,2,3,   4,5,6,  4,6,7,   // front/back
    0,4,7,  0,7,3,   1,5,6,  1,6,2,   // sides
    3,2,6,  3,6,7,   0,1,5,  0,5,4
  ]);
  const colors = new Float32Array([
    1,0,0, 1,0,0, 1,0,0, 1,0,0,
    0,1,0, 0,1,0, 0,1,0, 0,1,0
  ]);

  // create buffers
  const posBuf = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, posBuf);
  gl.bufferData(gl.ARRAY_BUFFER, positions, gl.STATIC_DRAW);

  const colBuf = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, colBuf);
  gl.bufferData(gl.ARRAY_BUFFER, colors, gl.STATIC_DRAW);

  const idxBuf = gl.createBuffer();
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, idxBuf);
  gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, indices, gl.STATIC_DRAW);

  const posLoc = gl.getAttribLocation(prog, 'position');
  gl.enableVertexAttribArray(posLoc);
  gl.bindBuffer(gl.ARRAY_BUFFER, posBuf);
  gl.vertexAttribPointer(posLoc, 3, gl.FLOAT, false, 0, 0);

  const colLoc = gl.getAttribLocation(prog, 'color');
  gl.enableVertexAttribArray(colLoc);
  gl.bindBuffer(gl.ARRAY_BUFFER, colBuf);
  gl.vertexAttribPointer(colLoc, 3, gl.FLOAT, false, 0, 0);

  const uMVP = gl.getUniformLocation(prog, 'uMVP');

  // simple matrix helpers
  function mmult(a,b){ const r = new Float32Array(16); for(let i=0;i<4;i++) for(let j=0;j<4;j++){ let s=0; for(let k=0;k<4;k++) s+=a[k*4 + j]*b[i*4 + k]; r[i*4 + j]=s;} return r; }
  function midentity(){ const m = new Float32Array(16); for(let i=0;i<16;i++) m[i]=(i%5===0)?1:0; return m; }
  function mtranslate(tx,ty,tz){ const m=midentity(); m[12]=tx; m[13]=ty; m[14]=tz; return m; }
  function mscale(s){ const m=midentity(); m[0]=s; m[5]=s; m[10]=s; return m; }
  function mrotateX(a){ const m=midentity(); const c=Math.cos(a), s=Math.sin(a); m[5]=c; m[6]= -s; m[9]= s; m[10]= c; return m; }
  function mrotateY(a){ const m=midentity(); const c=Math.cos(a), s=Math.sin(a); m[0]=c; m[2]= s; m[8]= -s; m[10]= c; return m; }
  function mperspective(fovy, aspect, near, far){
    const f = 1.0/Math.tan(fovy/2); const nf = 1/(near - far);
    const out = new Float32Array(16);
    out[0]=f/aspect; out[5]=f; out[10]=(far+near)*nf; out[11]=-1; out[14]=(2*far*near)*nf; out[15]=0; return out;
  }

  let angle = 0;
  let speed = 0.01;
  let scale = 1.0;
  let running = true;

  // controls UI
  function createControls(){
    const ctrl = document.createElement('div');
    ctrl.style.margin = '8px 0';
    ctrl.innerHTML = `
      <button id="three-play">Pause</button>
      <label>Speed: <input id="three-speed" type="range" min="0" max="0.1" step="0.001" value="${speed}"></label>
      <label>Scale: <input id="three-scale" type="range" min="0.2" max="3" step="0.01" value="${scale}"></label>
    `;
    container.appendChild(ctrl);
    document.getElementById('three-play').addEventListener('click', function(){
      running = !running; this.textContent = running ? 'Pause' : 'Play';
    });
    document.getElementById('three-speed').addEventListener('input', function(){ speed=parseFloat(this.value); });
    document.getElementById('three-scale').addEventListener('input', function(){ scale=parseFloat(this.value); });
  }
  createControls();

  function render(){
    resize();
    gl.clearColor(0.12,0.12,0.12,1);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.enable(gl.DEPTH_TEST);

    if(running) angle += speed;

    const proj = mperspective(Math.PI/4, canvas.width/canvas.height, 0.1, 100);
    const view = mtranslate(0,0,-6);
    const model = mmult(mrotateY(angle), mrotateX(angle*0.6));
    const modelScaled = mmult(model, mscale(scale));
    const mvp = mmult(proj, mmult(view, modelScaled));

    gl.uniformMatrix4fv(uMVP, false, mvp);
    gl.drawElements(gl.TRIANGLES, indices.length, gl.UNSIGNED_SHORT, 0);

    requestAnimationFrame(render);
  }
  render();

  // expose simple API for future glTF loader extensions
  window.threeViewer = {
    setSpeed: (v)=> speed = v,
    setScale: (s)=> scale = s,
    play: ()=> running = true,
    pause: ()=> running = false
  };
})();
